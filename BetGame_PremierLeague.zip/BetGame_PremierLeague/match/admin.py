from django.contrib import admin
from .models import Match, Matchweek

admin.site.register(Match)
admin.site.register(Matchweek)
