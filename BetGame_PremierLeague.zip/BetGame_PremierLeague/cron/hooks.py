def check_and_update_currently_matchweek_info(task):
    print(task.result)


def check_event_info(task):
    print(task.result)


def check_match(task):
    print(task.result)
