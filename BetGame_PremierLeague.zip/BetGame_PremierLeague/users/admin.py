from django.contrib import admin

from .models import Profile, UserScores

admin.site.register(Profile)
admin.site.register(UserScores)
